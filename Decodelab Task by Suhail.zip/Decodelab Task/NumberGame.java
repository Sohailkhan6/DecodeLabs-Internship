import java.util.Scanner;
import java.util.Random;

public class NumberGame {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Random random = new Random();
        
        boolean playAgain = true;
        int totalScore = 0;
        int roundNumber = 1;

        System.out.println("====== WELCOME TO THE NUMBER GUESSING GAME ======");

        while (playAgain) {
            // 1 se 100 ke beech random number generate karna
            int randomNumber = random.nextInt(100) + 1;
            int attemptsLeft = 5; // Max 5 attempts per round (Optional Enhancement)
            boolean hasGuessedCorrectly = false;

            System.out.println("\n--- Round " + roundNumber + " ---");
            System.out.println("Maine 1 se 100 ke beech ek number socha hai.");
            System.out.println("Aapke paas guess karne ke liye " + attemptsLeft + " attempts hain.");

            while (attemptsLeft > 0) {
                System.out.print("\nApna guess enter karein: ");
                int userGuess = scanner.nextInt();
                attemptsLeft--;

                if (userGuess == randomNumber) {
                    System.out.println("🎉 Mubarak ho! Aapne sahi number guess kar liya!");
                    // Jitne zyada attempts bachenge, utna zyada score milega
                    int roundScore = (attemptsLeft + 1) * 20; 
                    totalScore += roundScore;
                    System.out.println("Is round ka score: " + roundScore);
                    hasGuessedCorrectly = true;
                    break;
                } else if (userGuess > randomNumber) {
                    System.out.println("Too High! (Aapka guess bada hai).");
                } else {
                    System.out.println("Too Low! (Aapka guess chota hai).");
                }

                if (attemptsLeft > 0) {
                    System.out.println("Baqi attempts: " + attemptsLeft);
                }
            }

            if (!hasGuessedCorrectly) {
                System.out.println("\n☹️ Game Over! Aapke attempts khatam ho gaye.");
                System.out.println("Sahi number tha: " + randomNumber);
            }

            // Multiple rounds khelne ka option
            System.out.print("\nKya aap agla round khelna chahte hain? (yes/no): ");
            String response = scanner.next().toLowerCase();
            
            if (response.equals("yes") || response.equals("y")) {
                roundNumber++;
            } else {
                playAgain = false;
            }
        }

        // Final score display karna
        System.out.println("\n================================================");
        System.out.println("Game Khatam! Aapka Total Score hai: " + totalScore);
        System.out.println("Khelne ke liye shukriya! 👍");
        System.out.println("================================================");
        
        scanner.close();
    }
}