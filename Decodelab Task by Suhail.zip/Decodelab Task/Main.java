import java.util.Scanner;

// ==========================================
// 1. BANK ACCOUNT CLASS (Encapsulation)
// ==========================================
class BankAccount {
    private double balance;

    // Constructor initialization with a default balance
    public BankAccount(double initialBalance) {
        if (initialBalance >= 0) {
            this.balance = initialBalance;
        } else {
            this.balance = 0.0;
        }
    }

    // Getter for balance
    public double getBalance() {
        return balance;
    }

    // Deposit method with validation
    public void deposit(double amount) {
        if (amount > 0) {
            balance += amount;
            System.out.printf("Successfully deposited: $%.2f\n", amount);
        } else {
            System.out.println("❌ Error: Deposit amount must be positive.");
        }
    }

    // Withdrawal method with validation
    public boolean withdraw(double amount) {
        if (amount <= 0) {
            System.out.println("❌ Error: Withdrawal amount must be positive.");
            return false;
        } else if (amount > balance) {
            System.out.println("❌ Error: Insufficient balance for this transaction.");
            return false;
        } else {
            balance -= amount;
            System.out.printf("Successfully withdrew: $%.2f\n", amount);
            return true;
        }
    }
}

// ==========================================
// 2. ATM INTERFACE CLASS (User Interaction)
// ==========================================
class ATM {
    private BankAccount account;
    private Scanner scanner;

    // Constructor linking the ATM to a specific Bank Account
    public ATM(BankAccount account) {
        this.account = account;
        this.scanner = new Scanner(System.in);
    }

    // Displays the user menu interface
    public void start() {
        int choice;
        System.out.println("=== WELCOME TO THE ENTERPRISE ATM SYSTEM ===");
        
        do {
            System.out.println("\n--- Main Menu ---");
            System.out.println("1. Check Balance");
            System.out.println("2. Deposit Funds");
            System.out.println("3. Withdraw Funds");
            System.out.println("4. Exit");
            System.out.print("Please select an option (1-4): ");
            
            // Input validation for menu selection
            if (scanner.hasNextInt()) {
                choice = scanner.nextInt();
                performAction(choice);
            } else {
                System.out.println("❌ Invalid input! Please enter a number between 1 and 4.");
                scanner.next(); // Clear invalid input
                choice = -1;
            }
        } while (choice != 4);
    }

    // Routes execution based on user selection
    private void performAction(int choice) {
        switch (choice) {
            case 1:
                System.out.printf("💳 Your current balance is: $%.2f\n", account.getBalance());
                break;
                
            case 2:
                System.out.print("Enter deposit amount: $");
                double depositAmount = getValidAmount();
                account.deposit(depositAmount);
                break;
                
            case 3:
                System.out.print("Enter withdrawal amount: $");
                double withdrawAmount = getValidAmount();
                account.withdraw(withdrawAmount);
                break;
                
            case 4:
                System.out.println("Thank you for using our ATM service. Goodbye!");
                break;
                
            default:
                if (choice != -1) {
                    System.out.println("❌ Invalid choice. Please try again.");
                }
        }
    }

    // Helper method to validate that monetary input is a real number
    private double getValidAmount() {
        while (!scanner.hasNextDouble()) {
            System.out.println("❌ Invalid input. Please enter a valid monetary amount.");
            scanner.next(); // Clear buffer
            System.out.print("Enter amount: $");
        }
        return scanner.nextDouble();
    }
}

// ==========================================
// 3. MAIN RUNNER
// ==========================================
public class Main {
    public static void main(String[] args) {
        // Initialize bank account with a starting balance of $1000.00
        BankAccount userAccount = new BankAccount(1000.00);
        
        // Pass the account object to the ATM interface
        ATM atmInterface = new ATM(userAccount);
        
        // Boot up the ATM UI
        atmInterface.start();
    }
}